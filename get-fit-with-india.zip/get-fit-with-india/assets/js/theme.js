(() => {
  const qs = (selector) => document.querySelector(selector);
  const menuButton = qs('.menu-toggle');
  const menu = qs('#primary-nav');
  menuButton?.addEventListener('click', () => {
    const open = menu?.classList.toggle('is-open') ?? false;
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.textContent = open ? '×' : '☰';
  });
  menu?.addEventListener('click', (event) => {
    if (event.target.closest('a')) {
      menu.classList.remove('is-open');
      menuButton?.setAttribute('aria-expanded', 'false');
      if (menuButton) menuButton.textContent = '☰';
    }
  });

  const cartCount = qs('#cart-count');
  const toast = qs('#toast');
  let count = Number(sessionStorage.getItem('get-fit-with-indiaCart') || 0);
  let toastTimer;
  const updateCart = () => { if (cartCount) cartCount.textContent = String(count); };
  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2200);
  };
  updateCart();
  document.addEventListener('click', (event) => {
    const button = event.target.closest('.add-button');
    if (!button) return;
    count += 1;
    sessionStorage.setItem('get-fit-with-indiaCart', String(count));
    updateCart();
    cartCount?.classList.remove('bump');
    void cartCount?.offsetWidth;
    cartCount?.classList.add('bump');
    showToast(`${button.dataset.product || 'Product'} — ${gfiData.cartMessage}`);
  });
  qs('#shop-now')?.addEventListener('click', () => qs('#products')?.scrollIntoView({ behavior: 'smooth' }));

  window.setTimeout(() => {
    qs('#deal-loader')?.classList.add('is-hidden');
    qs('#deal-grid')?.classList.remove('is-hidden');
  }, 1100);

  const saleKey = 'get-fit-with-indiaSaleEnd';
  let end = Number(localStorage.getItem(saleKey));
  if (!end || end <= Date.now()) {
    end = Date.now() + 24 * 60 * 60 * 1000;
    localStorage.setItem(saleKey, String(end));
  }
  const tick = () => {
    const left = Math.max(0, end - Date.now());
    const values = [Math.floor(left / 3600000), Math.floor((left % 3600000) / 60000), Math.floor((left % 60000) / 1000)];
    ['#count-hours', '#count-minutes', '#count-seconds'].forEach((id, index) => {
      const element = qs(id);
      if (element) element.textContent = String(values[index]).padStart(2, '0');
    });
  };
  tick();
  window.setInterval(tick, 1000);

  const chatToggle = qs('#chat-toggle');
  const chatWindow = qs('#chat-window');
  const messages = qs('#chat-messages');
  const chatForm = qs('#chat-form');
  const chatInput = qs('#chat-input');
  const addMessage = (role, text) => {
    if (!messages) return;
    const message = document.createElement('div');
    message.className = `message ${role}`;
    message.textContent = text;
    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
  };
  const setChat = (open) => {
    chatWindow?.classList.toggle('is-hidden', !open);
    chatToggle?.setAttribute('aria-expanded', String(open));
    if (open && messages && messages.children.length === 0) addMessage('bot', gfiData.greeting);
    if (open) chatInput?.focus();
  };
  chatToggle?.addEventListener('click', () => setChat(chatWindow?.classList.contains('is-hidden') ?? true));
  qs('#chat-close')?.addEventListener('click', () => setChat(false));
  const reply = (question) => {
    const text = question.toLowerCase();
    if (text.includes('whey') || text.includes('protein')) return 'Whey Isolate Pro is a clean post-workout pick with easy mixing and low carbs.';
    if (text.includes('creatine')) return 'Creatine Monohydrate is usually taken at 3–5g daily. Stay hydrated and follow the product label.';
    if (text.includes('pre') || text.includes('workout')) return 'Take pre-workout around 20–30 minutes before training and always follow the serving guide.';
    if (text.includes('ship') || text.includes('deliver')) return 'Shipping is free above ₹999, with typical delivery in 2–5 days across India.';
    if (text.includes('hello') || text.includes('hi')) return 'Hey! What goal are you training for today?';
    return 'I can help with whey, creatine, pre-workout, equipment, or delivery. What would you like to know?';
  };
  chatForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    const text = chatInput?.value.trim();
    if (!text) return;
    addMessage('user', text);
    chatInput.value = '';
    window.setTimeout(() => addMessage('bot', reply(text)), 500);
  });
})();
