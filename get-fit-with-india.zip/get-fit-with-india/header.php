<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#main"><?php esc_html_e( 'Skip to content', 'get-fit-with-india' ); ?></a>
<header class="site-header">
    <div class="container nav-shell">
        <a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
            <?php if ( has_custom_logo() ) { the_custom_logo(); } else { echo esc_html( get_theme_mod( 'gfi_brand_name', 'GET FIT WITH INDIA' ) ); } ?>
        </a>
        <nav id="primary-nav" class="primary-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'get-fit-with-india' ); ?>">
            <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'gfi_anchor_menu_fallback' ) ); ?>
        </nav>
        <div class="nav-actions">
            <button class="cart-button" id="shop-now" type="button"><span class="cart-label"><?php esc_html_e( 'Shop now', 'get-fit-with-india' ); ?></span><span id="cart-count" class="cart-count">0</span></button>
            <button class="menu-toggle" type="button" aria-controls="primary-nav" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'get-fit-with-india' ); ?>">☰</button>
        </div>
    </div>
</header>
