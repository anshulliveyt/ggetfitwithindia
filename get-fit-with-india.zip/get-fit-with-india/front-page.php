<?php
get_header();
$theme_uri = get_template_directory_uri();
$hero_image = get_theme_mod( 'gfi_hero_image', $theme_uri . '/assets/images/hero.jpg' );
$products = array(
    array( 'Whey Isolate Pro', 2499, 'whey.jpg', 'Bestseller' ),
    array( 'Pre-Workout Burn', 1799, 'pre-workout.jpg', 'Hot' ),
    array( 'Adjustable Dumbbells', 8999, 'dumbbells.jpg', 'New' ),
    array( 'Resistance Band Set', 999, 'bands.jpg', '' ),
    array( 'Creatine Monohydrate', 1299, 'creatine.jpg', 'Popular' ),
    array( 'Olympic Barbell 20kg', 12499, 'barbell.jpg', '' ),
    array( 'Mass Gainer 5kg', 3299, 'mass-gainer.jpg', '' ),
    array( 'Smart Skipping Rope', 799, 'rope.jpg', '' ),
    array( 'BCAA Energy', 1599, 'bcaa.jpg', '' ),
    array( 'Yoga Mat Pro', 1499, 'yoga-mat.jpg', '' ),
    array( 'Kettlebell 16kg', 2199, 'kettlebell.jpg', '' ),
    array( 'Protein Bars (Box of 12)', 1199, 'protein-bars.jpg', '' ),
);
$flash_products = array(
    array( 'Whey Isolate Pro', 2499, 1499, 'whey.jpg' ),
    array( 'Pre-Workout Burn', 1799, 1079, 'pre-workout.jpg' ),
    array( 'Creatine Monohydrate', 1299, 779, 'creatine.jpg' ),
    array( 'BCAA Energy', 1599, 959, 'bcaa.jpg' ),
    array( 'Mass Gainer 5kg', 3299, 1979, 'mass-gainer.jpg' ),
    array( 'Kettlebell 16kg', 2199, 1319, 'kettlebell.jpg' ),
);
$reviews = array(
    array( 'Arjun Mehta', 'Powerlifter', 'arjun.jpg', "Best whey I've tasted in years. Mixes clean, no bloat." ),
    array( 'Priya Sharma', 'CrossFit Athlete', 'priya.jpg', 'Equipment build quality is gym-grade. Worth every rupee.' ),
    array( 'Rohan Iyer', 'Bodybuilder', 'rohan.jpg', 'Pre-workout hits hard without the crash. New favourite.' ),
    array( 'Neha Kapoor', 'Yoga Instructor', 'neha.jpg', 'Yoga mat grip is unreal. Class students keep asking.' ),
    array( 'Vikram Singh', 'Marathon Runner', 'vikram.jpg', 'Fast delivery, sealed packs, genuine batches every time.' ),
    array( 'Ananya Rao', 'Calisthenics Coach', 'ananya.jpg', 'Resistance bands feel premium. Recommended to all clients.' ),
);
?>
<main id="main">
<section id="home" class="hero" style="background-image:url('<?php echo esc_url( $hero_image ); ?>')">
    <div class="hero-content"><div class="hero-copy">
        <span class="pill">🔥 <?php echo esc_html( get_theme_mod( 'gfi_hero_badge', 'NEW SEASON DROP' ) ); ?></span>
        <?php $title = get_theme_mod( 'gfi_hero_title', 'Build Strength. Fuel Performance.' ); $parts = explode( '.', $title, 2 ); ?>
        <h1><?php echo esc_html( $parts[0] ); ?>.<?php if ( isset( $parts[1] ) ) : ?><br><span class="gradient-text"><?php echo esc_html( trim( $parts[1] ) ); ?>.</span><?php endif; ?></h1>
        <p><?php echo esc_html( get_theme_mod( 'gfi_hero_text', 'Premium supplements, gym-grade equipment, and accessories trusted by athletes across the globe.' ) ); ?></p>
        <div class="hero-actions"><a class="button" href="#products"><?php esc_html_e( 'Shop collection', 'get-fit-with-india' ); ?></a><a class="button button-outline" href="#deals"><?php esc_html_e( 'View flash sale', 'get-fit-with-india' ); ?></a></div>
    </div></div>
</section>
<section class="stats"><div class="container stats-grid"><div class="stat"><strong>50K+</strong><span>Happy customers</span></div><div class="stat"><strong>1000+</strong><span>Premium products</span></div><div class="stat"><strong>4.9★</strong><span>Average rating</span></div><div class="stat"><strong>100+</strong><span>Global brands</span></div></div></section>
<section class="container features" aria-label="Store benefits"><article class="feature"><span class="feature-icon">🚚</span><div><h3>Free Shipping</h3><p>On orders above ₹999, anywhere in India.</p></div></article><article class="feature"><span class="feature-icon">◆</span><div><h3>100% Authentic</h3><p>Every product sourced from authorised brands.</p></div></article><article class="feature"><span class="feature-icon">🏆</span><div><h3>Expert Curated</h3><p>Hand-picked by coaches and certified athletes.</p></div></article></section>
<section id="products" class="section"><div class="container"><header class="section-heading"><div><p class="eyebrow">Shop the drop</p><h2>Featured Products</h2></div><a class="text-link" href="#deals">View deals →</a></header><div class="product-grid">
<?php foreach ( $products as $index => $product ) : ?>
<article class="product-card" style="animation-delay:<?php echo esc_attr( $index * 0.04 ); ?>s"><div class="product-image"><img src="<?php echo esc_url( $theme_uri . '/assets/images/' . $product[2] ); ?>" alt="<?php echo esc_attr( $product[0] ); ?>" loading="lazy"><?php if ( $product[3] ) : ?><span class="product-tag"><?php echo esc_html( $product[3] ); ?></span><?php endif; ?></div><div class="product-body"><div class="product-name"><?php echo esc_html( $product[0] ); ?></div><div class="product-row"><span class="price">₹<?php echo esc_html( number_format_i18n( $product[1] ) ); ?></span><button class="add-button" type="button" data-product="<?php echo esc_attr( $product[0] ); ?>">Add</button></div></div></article>
<?php endforeach; ?>
</div></div></section>
<section id="deals" class="section"><div class="container"><div class="sale-panel"><div class="sale-panel-inner"><p class="eyebrow">Limited time</p><h2>Flash Sale</h2><p><?php echo esc_html( get_theme_mod( 'gfi_sale_text', 'Up to 40% off selected essentials.' ) ); ?></p><div class="countdown" aria-label="Sale countdown"><div class="time-box"><div id="count-hours" class="time-value">24</div><div class="time-label">Hours</div></div><div class="time-box"><div id="count-minutes" class="time-value">00</div><div class="time-label">Minutes</div></div><div class="time-box"><div id="count-seconds" class="time-value">00</div><div class="time-label">Seconds</div></div></div></div></div>
<div class="deals-heading"><p class="eyebrow">Limited stock</p><h2>Discounted Picks</h2></div><div id="deal-loader" class="loading-grid" aria-label="Loading deals"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div><div id="deal-grid" class="product-grid is-hidden">
<?php foreach ( $flash_products as $product ) : ?><article class="product-card"><div class="product-image"><img src="<?php echo esc_url( $theme_uri . '/assets/images/' . $product[3] ); ?>" alt="<?php echo esc_attr( $product[0] ); ?>" loading="lazy"><span class="product-tag sale-tag">-40%</span></div><div class="product-body"><div class="product-name"><?php echo esc_html( $product[0] ); ?></div><div class="product-row"><span><span class="old-price">₹<?php echo esc_html( number_format_i18n( $product[1] ) ); ?></span><span class="price">₹<?php echo esc_html( number_format_i18n( $product[2] ) ); ?></span></span><button class="add-button" type="button" data-product="<?php echo esc_attr( $product[0] ); ?>">Add</button></div></div></article><?php endforeach; ?>
</div></div></section>
<section id="reviews" class="section reviews-section"><header class="reviews-heading"><p class="eyebrow">Loved by athletes</p><h2>Customer Reviews</h2></header><div class="reviews-window"><div class="review-track">
<?php foreach ( array_merge( $reviews, $reviews ) as $review ) : ?><article class="review-card"><div class="review-person"><img class="review-avatar" src="<?php echo esc_url( $theme_uri . '/assets/images/' . $review[2] ); ?>" alt="<?php echo esc_attr( $review[0] ); ?>" loading="lazy"><div><div class="review-name"><?php echo esc_html( $review[0] ); ?></div><div class="review-role"><?php echo esc_html( $review[1] ); ?></div></div></div><div class="stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>“<?php echo esc_html( $review[3] ); ?>”</blockquote></article><?php endforeach; ?>
</div></div></section>
</main>
<?php get_footer(); ?>
