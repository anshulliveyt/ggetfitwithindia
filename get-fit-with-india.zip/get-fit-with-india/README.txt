GET FIT WITH INDIA WORDPRESS THEME

INSTALLATION
1. In WordPress, go to Appearance > Themes > Add New > Upload Theme.
2. Upload get-fit-with-india.zip, install, and activate it.
3. Go to Appearance > Customize > Get Fit With India Homepage to edit the hero, contact details, and social links.
4. Optionally create a menu under Appearance > Menus. Use custom links: #home, #products, #deals, #reviews, and #contact.

NOTES
- Product cards, product images, deals, and reviews are bundled into the theme.
- Add buttons update the on-page cart counter. This theme does not process checkout or payments.
- Gymo is an on-page rule-based helper and does not connect to an external AI service.
- Empty YouTube and LinkedIn settings leave their icons as placeholders until URLs are added.
