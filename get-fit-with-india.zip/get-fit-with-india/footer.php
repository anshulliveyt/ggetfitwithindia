<?php
$email = get_theme_mod( 'gfi_contact_email', 'anshul22062006@gmail.com' );
$phone = get_theme_mod( 'gfi_contact_phone', '+91 8882547578' );
$socials = array(
    'Instagram' => array( get_theme_mod( 'gfi_instagram_url', 'https://www.instagram.com/fitguy.111' ), '<circle cx="12" cy="12" r="4"/><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="17.5" cy="6.5" r=".7" fill="currentColor"/>' ),
    'Facebook' => array( get_theme_mod( 'gfi_facebook_url', 'https://www.facebook.com/profile.php?id=61575438005995' ), '<path d="M14 8h3V4h-3c-3 0-5 2-5 5v3H6v4h3v8h4v-8h3l1-4h-4V9c0-.7.3-1 1-1z" fill="currentColor" stroke="none"/>' ),
    'YouTube' => array( get_theme_mod( 'gfi_youtube_url', '' ), '<path d="M22 8s-.2-2-1-3c-.8-.8-2-.9-3-1-3-.2-6-.2-6-.2s-3 0-6 .2c-1 .1-2.2.2-3 1-.8 1-1 3-1 3S2 10 2 12v2c0 2 .2 4 .2 4s.2 2 1 3c.8.8 2 .9 3 1 3 .2 6 .2 6 .2s3 0 6-.2c1-.1 2.2-.2 3-1 .8-1 1-3 1-3s.2-2 .2-4v-2c0-2-.4-4-.4-4zM10 16V9l6 3.5z" fill="currentColor" stroke="none"/>' ),
    'LinkedIn' => array( get_theme_mod( 'gfi_linkedin_url', '' ), '<path d="M6 8H2v14h4V8zm-2-6a2.3 2.3 0 1 0 0 4.6A2.3 2.3 0 0 0 4 2zm18 12c0-4.2-2.2-6.2-5.2-6.2-2.4 0-3.5 1.3-4.1 2.2V8H9v14h4v-7c0-1.9.4-3.7 2.7-3.7 2.3 0 2.3 2.1 2.3 3.8V22h4v-8z" fill="currentColor" stroke="none"/>' ),
);
?>
<footer id="contact" class="site-footer">
    <div class="container footer-grid">
        <div><div class="brand"><?php echo esc_html( get_theme_mod( 'gfi_brand_name', 'GET FIT WITH INDIA' ) ); ?></div><p><?php esc_html_e( 'Premium fitness for relentless athletes.', 'get-fit-with-india' ); ?></p></div>
        <div><h3 class="footer-title"><?php esc_html_e( 'Contact', 'get-fit-with-india' ); ?></h3><p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a><br><a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p></div>
        <div><h3 class="footer-title"><?php esc_html_e( 'Follow', 'get-fit-with-india' ); ?></h3><div class="socials">
            <?php foreach ( $socials as $label => $social ) : $url = $social[0] ? $social[0] : '#'; ?>
                <a class="social-link" href="<?php echo esc_url( $url ); ?>" <?php if ( '#' !== $url ) : ?>target="_blank" rel="noopener noreferrer"<?php endif; ?> aria-label="<?php echo esc_attr( $label ); ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><?php echo $social[1]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></svg></a>
            <?php endforeach; ?>
        </div></div>
    </div>
    <p class="copyright">© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_theme_mod( 'gfi_brand_name', 'Get Fit With India' ) ); ?>. <?php esc_html_e( 'All rights reserved.', 'get-fit-with-india' ); ?></p>
</footer>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<button id="chat-toggle" class="chat-toggle" type="button" aria-label="<?php esc_attr_e( 'Open Gymo support', 'get-fit-with-india' ); ?>" aria-expanded="false">💬</button>
<section id="chat-window" class="chat-window is-hidden" aria-label="<?php esc_attr_e( 'Gymo support chat', 'get-fit-with-india' ); ?>">
    <div class="chat-header"><div class="chat-avatar">G</div><div><div class="chat-title">Gymo</div><div class="chat-status"><span class="online-dot"></span><?php esc_html_e( 'Online · Fitness support', 'get-fit-with-india' ); ?></div></div><button id="chat-close" class="chat-close" type="button" aria-label="<?php esc_attr_e( 'Close chat', 'get-fit-with-india' ); ?>">×</button></div>
    <div id="chat-messages" class="chat-messages" aria-live="polite"></div>
    <form id="chat-form" class="chat-form"><label class="screen-reader-text" for="chat-input"><?php esc_html_e( 'Your message', 'get-fit-with-india' ); ?></label><input id="chat-input" type="text" placeholder="<?php esc_attr_e( 'Ask Gymo anything…', 'get-fit-with-india' ); ?>" autocomplete="off"><button class="chat-send" type="submit" aria-label="<?php esc_attr_e( 'Send message', 'get-fit-with-india' ); ?>">➤</button></form>
</section>
<?php wp_footer(); ?>
</body>
</html>
