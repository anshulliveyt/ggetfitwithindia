<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function gfi_setup() {
    load_theme_textdomain( 'get-fit-with-india', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', array( 'height' => 64, 'width' => 240, 'flex-height' => true, 'flex-width' => true ) );
    add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
    register_nav_menus( array( 'primary' => __( 'Primary Menu', 'get-fit-with-india' ) ) );
}
add_action( 'after_setup_theme', 'gfi_setup' );

function gfi_assets() {
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'get-fit-with-india-style', get_stylesheet_uri(), array(), $version );
    wp_enqueue_script( 'get-fit-with-india-script', get_template_directory_uri() . '/assets/js/theme.js', array(), $version, true );
    wp_localize_script( 'get-fit-with-india-script', 'gfiData', array(
        'currency' => '₹',
        'cartMessage' => __( 'Added to your cart', 'get-fit-with-india' ),
        'greeting' => __( "Hey, I'm Gymo. Ask me about supplements, training gear, or delivery.", 'get-fit-with-india' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'gfi_assets' );

function gfi_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'gfi_content', array( 'title' => __( 'Get Fit With India Homepage', 'get-fit-with-india' ), 'priority' => 30 ) );
    $fields = array(
        'brand_name' => array( 'Brand name', 'GET FIT WITH INDIA', 'text' ),
        'hero_badge' => array( 'Hero badge', 'NEW SEASON DROP', 'text' ),
        'hero_title' => array( 'Hero heading', 'Build Strength. Fuel Performance.', 'text' ),
        'hero_text' => array( 'Hero description', 'Premium supplements, gym-grade equipment, and accessories trusted by athletes across the globe.', 'textarea' ),
        'sale_text' => array( 'Flash sale message', 'Up to 40% off selected essentials.', 'text' ),
        'contact_email' => array( 'Contact email', 'anshul22062006@gmail.com', 'email' ),
        'contact_phone' => array( 'Contact phone', '+91 8882547578', 'text' ),
        'instagram_url' => array( 'Instagram URL', 'https://www.instagram.com/fitguy.111', 'url' ),
        'facebook_url' => array( 'Facebook URL', 'https://www.facebook.com/profile.php?id=61575438005995', 'url' ),
        'youtube_url' => array( 'YouTube URL', '', 'url' ),
        'linkedin_url' => array( 'LinkedIn URL', '', 'url' ),
    );
    foreach ( $fields as $id => $field ) {
        $wp_customize->add_setting( 'gfi_' . $id, array( 'default' => $field[1], 'sanitize_callback' => 'textarea' === $field[2] ? 'sanitize_textarea_field' : ( 'email' === $field[2] ? 'sanitize_email' : ( 'url' === $field[2] ? 'esc_url_raw' : 'sanitize_text_field' ) ), 'transport' => 'refresh' ) );
        $wp_customize->add_control( 'gfi_' . $id, array( 'label' => __( $field[0], 'get-fit-with-india' ), 'section' => 'gfi_content', 'type' => $field[2] ) );
    }
    $wp_customize->add_setting( 'gfi_hero_image', array( 'default' => get_template_directory_uri() . '/assets/images/hero.jpg', 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'gfi_hero_image', array( 'label' => __( 'Hero background image', 'get-fit-with-india' ), 'section' => 'gfi_content' ) ) );
}
add_action( 'customize_register', 'gfi_customize_register' );

function gfi_anchor_menu_fallback() {
    echo '<ul><li><a href="#home">Home</a></li><li><a href="#products">Products</a></li><li><a href="#deals">Deals</a></li><li><a href="#reviews">Reviews</a></li><li><a href="#contact">Contact</a></li></ul>';
}
